jQuery(document).ready(function(){	
	//jQuery('tr.cart_item').remove();  
	//jQuery('tr.cart_item').show();         
	jQuery('tr.cart_item .remove').off('click');
});
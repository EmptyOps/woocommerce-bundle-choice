window.document.splugins = window.document.splugins || {};
window.document.splugins.ui.slider = jQuery.fn.slider;
window.document.splugins.ui.tab = jQuery.fn.tab;
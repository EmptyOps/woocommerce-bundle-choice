<?php

add_filter('eowbc_filter_sidebars_widgets',function(){
	return false;
});

jQuery(document).ready(function($){
	jQuery('.allow_addition').dropdown({
    	allowAdditions: true,
    	clearable: true
	})
});
jQuery.fn.ui_accordion = jQuery.fn.accordion;

<style type="text/css">
	.wrap,.entry-content{
		min-width: 100% !important;
		max-width: 100% !important;
		width: 100% !important;
	}
</style>
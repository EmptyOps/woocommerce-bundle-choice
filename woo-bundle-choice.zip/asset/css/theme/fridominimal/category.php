
<?php if(wp_is_mobile()): ?>
<style type="text/css">

</style>
<?php else: ?>
<style type="text/css">
	#content{ 
		max-width:98% !important; 
	}
</style>
<?php endif; ?>
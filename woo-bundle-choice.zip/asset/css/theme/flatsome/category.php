<style type="text/css">
.row.category-page-row>.col.large-3{
	display: none !important;
}
.row.category-page-row>.col.large-9{
	max-width:100% !important;
	min-width:100% !important;
}
</style>
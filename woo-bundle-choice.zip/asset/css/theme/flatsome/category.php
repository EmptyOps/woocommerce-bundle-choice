<style type="text/css">
.row.category-page-row>.col.large-3{
	display: none !important;
}
.row.category-page-row>.col.large-9{
	max-width:100% !important;
	min-width:100% !important;
}
/*PATIA -- product pagee ++ checkout page*/
/*.image-tools.bottom.left a i {
	top: 6.5px;
}
#checkout_timeline.style4.horizontal li:not(:last-child) .timeline-wrapper:after{
	top: 70px;
	bottom: auto;
}
#checkout_timeline{
	max-height: 100px;
}

@media only screen and (max-width: 480px){
	
.next-prev-thumbs .button i {
top: 4.5px;
}

.cart-container.container.page-wrapper.page-checkout .woocommerce {
width: 100%;
float: left;

}
div#checkout-wrapper {
float: left;
width: 100%;
}
form.checkout.woocommerce-checkout {
width: 100%;
float: left;
}
#checkout_timeline {
max-height: inherit;
width: 100%;
float: left;
height: auto;
}
li#timeline-billing {
width: 100%;
float: left;
}
.timeline-wrapper {
width: 100%;
float: left;
}
.yith-wcms-pro #checkout_timeline li {
cursor: pointer;
width: 100%;
float: left;
}
div#customer_billing_details {
float: left;
width: 100%;
}
.woocommerce-billing-fields {
width: 100%;
float: left;
}
.woocommerce-billing-fields__field-wrapper {
width: 100%;
float: left;
}
.woocommerce-billing-fields p {
margin-bottom: .5em;
width: 100%;
float: left;
}
#form_actions {
text-align: right;
width: 100%;
float: left;
}
.woocommerce-privacy-policy-text {
font-size: 85%;
width: 100%;
float: left;
}
.woocommerce-privacy-policy-text p {

float: left;

}
	
}

*/



</style>
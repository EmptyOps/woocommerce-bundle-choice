<style type="text/css">
.ui.grid>.column:not(.row), .ui.grid>.row>.column{
	width: 6.25% !important;
}
.social-icons i[class^="icon-"]{
	line-height:2 !important;
}

.social-icons .primary{
	width: auto !important;
}
</style>
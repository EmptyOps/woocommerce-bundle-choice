<style type="text/css">
.ui.grid>.column:not(.row), .ui.grid>.row>.column{
	width: 6.25% !important;
}
</style>
<?php 

add_filter('eowbc_filter_sidebars_widgets','__return_false');

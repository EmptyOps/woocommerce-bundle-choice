<style type="text/css">
	.container{
		width: 100% !important;
	}
	#main-content .container{
		padding-top: 1em !important;
	}
	.eo-wbc-container.filters.container.ui.form{
		width: 100%;
		margin-left: 0;
		margin-right: 0;
	}
	.eo-wbc-container>.ui.steps .step::after{
		border-top: 4em solid transparent !important;
    	border-bottom: 4em solid transparent !important;
	}	

	.eo-wbc-container>.ui.steps .step:not(:first-child):before{
		border-top: 4em solid transparent !important;
    	border-bottom: 4em solid transparent !important;
    	border-left: 1em solid #d2d2d2 !important;
	}

</style>
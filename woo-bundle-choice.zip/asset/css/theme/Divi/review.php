<style type="text/css">
	.container{
		width: 100% !important;
	}

	#main-content>.container{
		padding-top: 1em !important;
		margin-left: 5% !important;
		margin-right:5% !important;
		max-width: unset;
    	width: 90% !important;
	}
	.eo-wbc-container.container{
		margin: 0px !important;
		width: 100% !important;
		min-width: 100% !important;
	}
</style>
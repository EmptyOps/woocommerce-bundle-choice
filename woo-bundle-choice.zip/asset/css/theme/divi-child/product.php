<style type="text/css">
	.container{
		width: 100% !important;
	}

	#main-content .container{
		padding-top: 1em !important;
	}
</style>
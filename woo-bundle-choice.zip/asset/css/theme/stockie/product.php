<style type="text/css">

div.eo-wbc-container.container{
	display: none;
}
</style>

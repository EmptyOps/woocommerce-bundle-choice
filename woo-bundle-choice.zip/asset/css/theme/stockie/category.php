<?php
	\StockieSettings::$settings_cache[ 'global_shop_content_position'] = 'top';
?>
<style type="text/css">
	.eo-wbc-container.filters.container{
		margin: 0px !important;
		width: 100% !important;
	}

</style>
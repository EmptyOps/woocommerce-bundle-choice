<style type="text/css">
	.eo-wbc-container .ui.steps .ui.equal.width.grid{
		padding-top:0 !important;
		padding-bottom:0 !important;
	}
</style>
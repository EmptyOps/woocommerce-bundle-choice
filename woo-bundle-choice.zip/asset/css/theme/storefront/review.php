<style type="text/css">
	#content .col-full{
		min-width: 100% !important;
		max-width: 100% !important;
		width: 100% !important;
		margin: 0px !important;
		padding: 0px !important;
	}
</style>
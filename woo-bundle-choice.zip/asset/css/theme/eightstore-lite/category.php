<style type="text/css">
	.container{
		width: 100% !important;
	}

	#main-content .container{
		padding-top: 1em !important;
	}

	.eo-wbc-container.filters.container.ui.form{
		width: 100%;
		margin-left: 0;
		margin-right: 0;
	}
	.eo-wbc-container .wide.column>.wide.field.num_slider{
		margin-top: 0.35em;
	}
	.ui.labeled.ticked.range.slider .labels{
		bottom: -0.7em;
		left: -0.3em;
	}
	.eo_wbc_filter_icon{
		font-size: x-small !important;
	}
</style>
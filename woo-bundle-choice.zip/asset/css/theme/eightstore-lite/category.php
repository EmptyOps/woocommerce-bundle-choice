<style type="text/css">

	.container,.eo-wbc-container.filters.container{
		width: 100% !important;
		margin: 0 !important;
	}

	#main-content .container{
		padding-top: 1em !important;
	}

	.eo-wbc-container.filters.container.ui.form{
		width: 100%;
		margin-left: 0;
		margin-right: 0;
	}
	.eo-wbc-container .wide.column>.wide.field.num_slider{
		margin-top: 0.35em;
	}
	.ui.labeled.ticked.range.slider .labels{
		bottom: -0.7em;
		left: -0.3em;
	}
	.eo_wbc_filter_icon{
		font-size: x-small !important;
	}
	
	.top-ticker{
		display:none;
	}
	.eo-wbc-container .field>.ui.header .question.circle.outline.icon{
		font-size: 1em;
		margin-top:1px;
	}
	.store-wrapper{
		padding: 1em !important;
		width: 100% !important;
	}
	.woocommerce-products-header__title.page-title{
		display: none;
	}
</style>
<style type="text/css">
#primary{
	width:100% !important;
}
.ui.grid>.relaxed.row>.column, .ui.relaxed.grid>.column:not(.row), .ui.relaxed.grid>.row>.column{
	margin-right:1.3em;
}

.eo-wbc-container.container.filters .ui.grid:not(.eo_wbc_filter_icon)>*{
	padding-left:2em !important;
	padding-right:1em !important;
}
</style>
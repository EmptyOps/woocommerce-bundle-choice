<style type="text/css">
	.eo-wbc-container.container{
		margin: 0 !important;
		max-width: unset !important;
	    min-width: unset !important;
	    width: 100% !important;
	    padding: 0 !important;
	}
	aside.sidebar-container{
		display: none !important;
	}
	div.site-content{
		max-width: unset !important;
	    min-width: unset !important;
	    width: 100% !important;
	}
	.ui.steps .step .title{
		margin:0 !important;
	}
	.eo-wbc-container > .ui.steps .step.active .title {
	    color: black !important;
	}
	/*.woodmart-shop-tools{
		display: none !important;
	}*/
	.page-title.page-title-default{
		display: none !important;
	}
</style>
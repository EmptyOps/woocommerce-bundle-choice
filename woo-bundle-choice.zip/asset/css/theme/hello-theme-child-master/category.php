<style type="text/css">
	.ui.tiny.images.ui.equal.width.center.aligned.grid{
		width: 100% !important;
	}
</style>
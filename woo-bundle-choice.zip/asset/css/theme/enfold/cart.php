<?php
	add_filter('eowbc_filter_sidebars_widgets','__return_false');
	/*add_filter( 'sidebars_widgets',function($sidebars_widgets ) {
		//var_dump($sidebars_widgets);
        return $sidebars_widgets;
    },7);*/	
?>
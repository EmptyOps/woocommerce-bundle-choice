<style type="text/css">
	.sml-single-cart-wrapp.sml-single-product-outer{
		display: block !important;
	}
</style>
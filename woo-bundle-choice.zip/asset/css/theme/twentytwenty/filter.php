<style type="text/css">
	.ui.grid{
		min-width: unset !important;
		max-width: unset !important;
		width:100% !important;
	}
	.ui.grid.centered>.row{
		padding-top: 0px;
	}
</style>
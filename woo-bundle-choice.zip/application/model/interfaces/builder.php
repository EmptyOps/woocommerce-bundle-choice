<?php
/**
*	An interface for every builders.
*/

namespace eo\wbc\model\interfaces;

defined( 'ABSPATH' ) || exit;

interface Builder {
	/**
	*	A generic function to build an object for the classes.
	*/
	public function build(array $build_data);	
}

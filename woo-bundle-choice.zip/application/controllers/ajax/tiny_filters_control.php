<?php
if(isset($_POST['slug']) && isset($_POST['type']) ) {
    wbc()->load->model('publics/component/eowbc_filter_widget');
    $widget = \eo\wbc\model\publics\component\EOWBC_Filter_Widget::instance();       
        
    $slug = sanitize_text_field($_POST['slug']);

    $term=get_term_by('slug',$slug,'product_cat');

    $id=$term->term_id;
    $label=sanitize_text_field($_POST['title']);
    $type=sanitize_text_field($_POST['type']);        

    $filter=$widget->range_steps($id,$label,$type);                                                     
    $widget->input_dropdown($filter['slug'],
            array_column($filter['list'],'name'),
            array_column($filter['list'],'slug'),
            $id,
            $type,
            $label
    );
}
else{
   	echo '';
}
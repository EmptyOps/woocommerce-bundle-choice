<?php

namespace eo\wbc\controllers\publics;

defined( 'ABSPATH' ) || exit;

class Controller extends \eo\wbc\controllers\Controller{

	/*protected function __construct() {
		
	}*/	

	protected function _get($name) {

	}

	protected function _set() {

	}

	protected function _call() {

	}	
}

<?php

namespace eo\wbc\controllers;

defined( 'ABSPATH' ) || exit;

class Controller {

	private static $_instance = null;

	/*protected function __construct() {
		
	}	*/

	protected function _get($name) {

	}

	protected function _set() {

	}

	protected function _call() {

	}
}

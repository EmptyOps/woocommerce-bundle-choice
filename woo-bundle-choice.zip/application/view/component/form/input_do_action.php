<?php
/**
*	template to show small visible info text 
*/
if(!empty($name)){
	do_action($name);
}
<?php
/**
*	A devider in form works as seperator in form.
*/
if(!empty($label)){?><h4 class="ui dividing header"><?php echo $label;?></h4><?php } ?>
<?php

/**
*
*	icon template
*/

?>

<i class="<?php echo !empty($icon_class) ? $icon_class : "";?> icon"></i>

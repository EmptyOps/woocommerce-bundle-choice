<td class="<?php !empty($class)?_e($class):''; ?>" id="<?php !empty($id)?_e($id):''; ?>" style="<?php !empty($style)?_e($style):''; ?>" <?php !empty($attr)? _e($attr) : ''; ?>>
	<?php !empty($label)?_e($label):''; ?>
	<?php 
	    if(!empty($builder) and !empty($child)){
	      $builder->build($child,$option_key,$process_form);
	    }
  	?>
</td>
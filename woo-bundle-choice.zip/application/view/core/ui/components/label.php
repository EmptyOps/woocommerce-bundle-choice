<?php 
	//Semantic UI : fields
?>

 <label class="<?php !empty($class) ? _e($class) : ''; ?>" style="<?php !empty($style) ? _e($style) : ''; ?>"  ><?php _e($label); ?></label>

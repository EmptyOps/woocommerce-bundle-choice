<?php 
	if(!empty($callable)){
		$callable();
	}
?>
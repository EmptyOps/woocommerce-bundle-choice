<?php 
	if(!empty($src)){
		wbc()->load->template($src);
	}
?>
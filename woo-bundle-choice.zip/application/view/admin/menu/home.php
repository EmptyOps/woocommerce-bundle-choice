<?php

/*
*	Admin's home page
*	--	may add up system status like total products, mappings, filters short status panel.
*/

wbc()->load->template('admin/menu/steps/steps');
wbc()->load->template('admin/menu/steps/step-help');
<?php 

/*
*	Specification view temlate part.
*/


    global $product;
    
    $product_data = array();
    $sku = $product->get_sku();
    if(!empty($sku)){
        $product_data[]=array('SKU',$sku);    
    }            

    if($product->has_weight()){
       $product_data[]=array('Weight',$product->get_weight());
    }

    if($product->has_dimensions()){
        $product_data[]=array('Height',$product->get_height());
        $product_data[]=array('Width',$product->get_width());
        $product_data[]=array('Length',$product->get_length());                
    }

    if($product->has_attributes()){
        $attributes = $product->get_attributes();
        if(!empty($attributes) and !is_wp_error($attributes)){
            foreach ($attributes as $key => $attribute) {
                $terms=$attribute['options'];                        

                if(!empty($terms) and !is_wp_error($terms)){
                    $_term_list_ = array();
                    foreach ($terms as $term_id) {
                        $_term_ = get_term_by( 'id',$term_id,$attribute['name']); 
                        if( !empty($_term_) && !is_wp_error($_term_) && is_object($_term_) && property_exists($_term_,'name')) {
                            $_term_list_[] = $_term_->name;   
                        }
                    }
                    $product_data[]=array(wc_attribute_label($attribute->get_name()),implode(', ',$_term_list_));
                }                        //get_term_by( 'id',,$attribute['name']);    
            }
        }
    }

    if(!empty($product_data)){
        $display_style = wbc()->options->get_option('tiny_features','specification_view_style','default');
        if('default'===$display_style){
            if(sizeof($product_data) > 1) {
                list($product_data_1, $product_data_2) = array_chunk($product_data, ceil(count($product_data) / 2));
                wbc()->load->template('publics/features/default',compact('product_data','product_data_1','product_data_2'));
            }
            else {
                wbc()->load->template('publics/features/default',compact('product_data'));
            }
        } elseif ('template_1'===$display_style) {            
            wbc()->load->template('publics/features/template_1',compact('product_data'));
            
        } elseif ('template_2'===$display_style) {
            wbc()->load->template('publics/features/template_2',compact('product_data'));
        }
    }
   
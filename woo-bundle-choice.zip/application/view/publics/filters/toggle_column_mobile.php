<div class="title">
	<i class="dropdown icon"></i>		    
	<?php echo $term->name; ?>	
</div>
<div class="content">	
	<div class="ui toggle button" id="togle_column_<?php echo $term->slug ?>" data-toggle_column="<?php echo $term->slug ?>" style="text-align: center;vertical-align: center; width: 100%;margin: auto;">Add Column</div>	
</div>		

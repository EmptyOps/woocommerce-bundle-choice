<div class="<?php echo $width_class; ?>">
	<p>
		<span class="ui header"><?php echo $term->name; ?></span>		
	</p>		
	<div class="ui toggle button" id="togle_column_<?php echo $term->slug ?>" data-toggle_column="<?php echo $term->slug ?>" style="text-align: center;vertical-align: center; width: 100%;margin: auto;"><?php echo eowbc_lang('Add Column'); ?></div>
</div>
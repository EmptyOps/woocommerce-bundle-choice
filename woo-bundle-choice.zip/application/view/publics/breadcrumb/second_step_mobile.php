<?php

/*
*	Template to show breadcrumb first step for mobile
*/

?>
<div class="step <?php echo (($step==$order)?'active ':(($step>$order)?'completed ':'disabled')); ?> second_mobile">
    <div class="content"><?php echo get_option('eo_wbc_second_name',''); ?></div>
    <div class="ui flowing popup bottom right transition hidden second_mobile" style="width: 80%;">
        <div class="ui grid">
            <div class="six wide column" style="width: 80px;height: auto;margin: auto;">
                <?php if(!empty(self::$second)) : ?>
                <?php echo self::$second->get_image(); ?>
                <?php endif; ?>
            </div>
            <div class="ten wide column">
                <div class="ui header">
                    <?php if(!empty(self::$second)) : ?>
                    <?php _e(wc_price(self::$second->get_price())); ?>
                    <?php endif; ?>
                </div>
                <br/>
                <div class="ui equal width grid">                            
                    <u><a href="<?php echo !empty(wbc()->sanitize->get('SECOND')) ? self::eo_wbc_breadcrumb_view_url(wbc()->sanitize->get('SECOND'),$order):'#'; ?>">View</a>
                    </u>
                    <u>
                        <a href="<?php echo !empty(wbc()->sanitize->get('SECOND'))?self::eo_wbc_breadcrumb_change_url($order,wbc()->sanitize->get('SECOND')):'#'; ?>">Remove</a>
                    </u>
                </div>  
            </div>                
        </div>
    </div>                          
</div>
<script>
    jQuery(document).ready(function(){
        jQuery('.step.completed.second_mobile').popup({
            popup : jQuery('.ui.popup.second_mobile'),
            on    : 'click',
            target   :jQuery('.step.completed.second_mobile').parent(),
            position : 'bottom left',
            inline: true
        });
    });
</script>
<?php
/*
* Boilerplate - DO NOT TOUCH ANY LINES HERE.
* FUTURE : TO BE MOVED TO COMMON FILE.
*/
$wp_tests_dir = getenv( 'WP_TESTS_DIR' ) ? getenv( 'WP_TESTS_DIR' ) : '/tmp/wordpress-tests-lib';
require_once $wp_tests_dir . '/includes/functions.php';
require_once $wp_tests_dir . '/includes/bootstrap.php';
require_once $wp_tests_dir . '/includes/listener-loader.php';

require_once dirname( dirname( __FILE__ ) ) . '/woo-bundle-choice.php';		

activate_plugin('woocommerce/woocommerce.php');
activate_plugin('woocommerce-bundle-choice/woo-bundle-choice.php');		
/////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////

/**
* Backend unit testing.
*/
class AdminAppearance extends WP_UnitTestCase {

    public function test_woocommerce_exists(){		
		$this->assertTrue( class_exists('WooCommerce') );
	}

	public function test_save_Appearancedata(){

		require_once(constant('EO_WBC_PLUGIN_DIR'). 'EO_WBC_Admin/EO_WBC_Config/EO_WBC_View/EO_WBC_View_Head_Banner.php');		
		require_once(constant('EO_WBC_PLUGIN_DIR').'EO_WBC_Admin/EO_WBC_Config/EO_WBC_Actions.php');
		require_once(constant('EO_WBC_PLUGIN_DIR').'EO_WBC_Admin/EO_WBC_Config/EO_WBC_View/EO_WBC_View_Personalize.php');


		$Testdata1 = $_POST['eo_wbc_home_btn_tagline'] = 'hello';
		$Testdata2 = $_POST['eo_wbc_home_default_button'] = '1';
		$Testdata3 = $_POST['eo_wbc_home_btn_color'] = 'green';
		$Testdata4 = $_POST['eo_wbc_show_hide_breadcrumb_icon'] = '1';
		$_POST['eo_wbc_action'] = 'eo_wbc_personalize';
		$_POST['_wpnonce'] = wp_create_nonce('eo_wbc_personalize');
		$SaveForm = new EO_WBC_Actions();

		$this->assertEquals($Testdata1,get_option('eo_wbc_home_btn_tagline'));
		$this->assertEquals('0',get_option('eo_wbc_home_default_button'));
		$this->assertEquals($Testdata3,get_option('eo_wbc_home_btn_color'));
		$this->assertEquals($Testdata4,get_option('eo_wbc_show_hide_breadcrumb_icon'));

	}

}